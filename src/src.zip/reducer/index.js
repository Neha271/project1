import loggedReducer from '../reducer/isLogged'
import  counterReducer from '../reducer/counter'
import {combineReducers} from 'redux'
 const allReducer = combineReducers({
     counter : counterReducer,
     islog :loggedReducer
 })
 export default allReducer;