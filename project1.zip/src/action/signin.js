export const signin=()=>{
    return{
        type:'SIGN_IN'
    };
};
export const signoff=()=>{
    return{
        type:'SIGN_OFF'
    };
};
